from flask import Flask, render_template, request, redirect, url_for, session, flash
import sqlite3
from datetime import datetime, timedelta
from decimal import Decimal, InvalidOperation
from werkzeug.security import generate_password_hash, check_password_hash
from pathlib import Path
import os

BASE = Path(__file__).resolve().parent
DB = BASE / "investment_demo.db"

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "change-this-secret-key")

# DEMO ONLY: no real deposits, withdrawals, or payment processing.
DEMO_RATE = Decimal("0.10")  # illustrative 10% simulated return


def db():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = db()
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS investments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        amount REAL NOT NULL,
        rate REAL NOT NULL,
        start_at TEXT NOT NULL,
        maturity_at TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'active',
        created_at TEXT NOT NULL,
        FOREIGN KEY(user_id) REFERENCES users(id)
    );
    """)
    conn.commit()
    conn.close()


@app.before_request
def setup():
    init_db()


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")

        if not name or not email or len(password) < 6:
            flash("Enter your name, a valid email, and a password of at least 6 characters.")
            return redirect(url_for("register"))

        conn = db()
        try:
            conn.execute(
                "INSERT INTO users(name,email,password_hash,created_at) VALUES(?,?,?,?)",
                (name, email, generate_password_hash(password), datetime.utcnow().isoformat())
            )
            conn.commit()
        except sqlite3.IntegrityError:
            conn.close()
            flash("That email is already registered.")
            return redirect(url_for("register"))
        conn.close()

        flash("Account created. You can now log in.")
        return redirect(url_for("login"))

    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")

        conn = db()
        user = conn.execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
        conn.close()

        if user and check_password_hash(user["password_hash"], password):
            session["user_id"] = user["id"]
            session["user_name"] = user["name"]
            return redirect(url_for("dashboard"))

        flash("Incorrect email or password.")

    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("index"))


@app.route("/dashboard")
def dashboard():
    if "user_id" not in session:
        return redirect(url_for("login"))

    conn = db()
    investments = conn.execute(
        "SELECT * FROM investments WHERE user_id=? ORDER BY id DESC",
        (session["user_id"],)
    ).fetchall()
    conn.close()

    now = datetime.utcnow()
    rows = []
    for inv in investments:
        maturity = datetime.fromisoformat(inv["maturity_at"])
        profit = float(Decimal(str(inv["amount"])) * Decimal(str(inv["rate"])))
        total = float(inv["amount"]) + profit
        status = "matured" if now >= maturity else "active"
        rows.append({
            "id": inv["id"],
            "amount": inv["amount"],
            "rate": inv["rate"],
            "start_at": inv["start_at"],
            "maturity_at": inv["maturity_at"],
            "status": status,
            "profit": profit,
            "total": total
        })

    return render_template("dashboard.html", investments=rows, demo_rate=float(DEMO_RATE))


@app.route("/invest", methods=["POST"])
def invest():
    if "user_id" not in session:
        return redirect(url_for("login"))

    try:
        amount = Decimal(request.form.get("amount", "0"))
    except InvalidOperation:
        amount = Decimal("0")

    # Demo boundaries. No real money is accepted.
    if amount < Decimal("100"):
        flash("Demo investment must be at least KSh 100.")
        return redirect(url_for("dashboard"))

    if amount > Decimal("1000000"):
        flash("Demo investment is limited to KSh 1,000,000.")
        return redirect(url_for("dashboard"))

    start = datetime.utcnow()
    maturity = start + timedelta(days=3)

    conn = db()
    conn.execute(
        """INSERT INTO investments
           (user_id, amount, rate, start_at, maturity_at, status, created_at)
           VALUES (?,?,?,?,?,?,?)""",
        (
            session["user_id"], float(amount), float(DEMO_RATE),
            start.isoformat(), maturity.isoformat(), "active", start.isoformat()
        )
    )
    conn.commit()
    conn.close()

    flash("Demo investment created. No real money was charged.")
    return redirect(url_for("dashboard"))


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)), debug=False)
