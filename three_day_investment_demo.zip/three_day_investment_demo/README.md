# Three-Day Investment Demo

This is a **simulation/demo website**. It is intentionally not connected to M-Pesa, banks, cards, or any other real-money payment system.

## Features
- Registration and login
- Secure password hashing
- SQLite database
- Three-day maturity timestamp
- Illustrative 10% simulated return
- Investment history
- Mobile-friendly UI
- Render deployment configuration

## Run locally

```bash
pip install -r requirements.txt
python app.py
```

Open `http://127.0.0.1:5000`.

## Deploy to Render

1. Create a GitHub repository.
2. Upload all files while preserving the `templates/` and `static/` folders.
3. In Render, create a new Web Service from the GitHub repository.
4. Build command: `pip install -r requirements.txt`
5. Start command: `gunicorn app:app`
6. Add a strong `SECRET_KEY` environment variable (Render can generate one).
7. Deploy.

## Important production note

SQLite on a normal Render web-service filesystem should not be treated as permanent production storage. For a real service, use a managed persistent database such as PostgreSQL and appropriate backups.

Before taking real customer funds, obtain qualified Kenyan legal/compliance advice and use properly licensed/regulated financial and payment arrangements. Do not advertise guaranteed profits unless lawful and accurately disclosed.
